﻿(function () {
    "use strict";
    var app = angular.module("loggin");
    app.controller("HomeCtrl",HomeCtrl);

    function HomeCtrl(){
        var vm = this;
        vm.message = "ceci est un test";

        vm.loggedIn = function () {
            redirectTo: "/loggedInView.html";
        }

        vm.register = function () {
            redirectTo: "/registerView.html";
        }
    }

}())