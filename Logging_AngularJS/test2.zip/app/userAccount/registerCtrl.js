﻿(function () {
    "use strict";
    angular
        .module("loggin")
        .controller("registerCtrl", registerCtrl);

    function registerCtrl() {
        var vm = this;

    }

}());