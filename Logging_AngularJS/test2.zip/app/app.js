﻿(function () {
    "use strict";

    var app = angular.module("loggin", ["ngRoute"]);

    app.config(function ($routeProvider) {
        $routeProvider
            .when("/home", {
                templateUrl:"app/userAccount/homeView.html"
            })
            .when("/register", {
                templateUrl: "userAccount/registerView.html",
                controller: "userAccount/registerCtrl.js"
            })
            .when("/loggedIn", {
                templateUrl: "userAccount/loggedInView.html",
                controller: "userAccount/loggedInCtrl.js"
            })
            .otherwise({ redirectTo: "/home" });
    });

}());